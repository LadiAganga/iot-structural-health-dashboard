'use client'

import { useState, useEffect } from 'react'
import { Activity, Gauge, TrendingUp, AlertCircle, MoreVertical, Calendar } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  'https://oybyqbeeibjterpozhpo.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im95YnlxYmVlaWJqdGVycG96aHBvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzE3ODQ2MzgsImV4cCI6MjA0NzM2MDYzOH0.R_P0sPdh7qf3YlCp-XXDLB_p_JQVT7-rBYY_1KkV74s'
)

export default function DashboardPage() {
  const [liveStrain, setLiveStrain] = useState(0)
  const [maxStrain, setMaxStrain] = useState(0)
  const [avgStrain, setAvgStrain] = useState(0)
  const [chartData, setChartData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      try {
        const { data, error } = await supabase
          .from('sensor_data')
          .select('strain, created_at')
          .order('created_at', { ascending: true })
          .limit(24)

        if (error) throw error

        // Format data for charts
        const formattedData = (data || []).map((record: any) => ({
          time: new Date(record.created_at).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }),
          strain: record.strain,
          timestamp: record.created_at,
        }))

        setChartData(formattedData)
        
        // Extract stats from data
        const strainValues = formattedData.map((d: any) => d.strain)
        if (strainValues.length > 0) {
          const currentStrain = strainValues[strainValues.length - 1]
          const maxValue = Math.max(...strainValues)
          const avgValue = strainValues.reduce((a: number, b: number) => a + b, 0) / strainValues.length
          
          setLiveStrain(currentStrain)
          setMaxStrain(maxValue)
          setAvgStrain(avgValue)
        }
      } catch (error) {
        console.error('Failed to load sensor data:', error)
      } finally {
        setIsLoading(false)
      }
    }
    
    loadData()

    const subscription = supabase
      .channel('sensor_data_changes')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'sensor_data' },
        async (payload) => {
          // Refresh data when new records are inserted
          const { data, error } = await supabase
            .from('sensor_data')
            .select('strain, created_at')
            .order('created_at', { ascending: true })
            .limit(24)

          if (!error && data) {
            const formattedData = data.map((record: any) => ({
              time: new Date(record.created_at).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }),
              strain: record.strain,
              timestamp: record.created_at,
            }))

            setChartData(formattedData)
            
            const strainValues = formattedData.map((d: any) => d.strain)
            if (strainValues.length > 0) {
              const currentStrain = strainValues[strainValues.length - 1]
              const maxValue = Math.max(...strainValues)
              const avgValue = strainValues.reduce((a: number, b: number) => a + b, 0) / strainValues.length
              
              setLiveStrain(currentStrain)
              setMaxStrain(maxValue)
              setAvgStrain(avgValue)
            }
          }
        }
      )
      .subscribe()

    return () => {
      subscription.unsubscribe()
    }
  }, [])

  const getStatusColor = (value: number) => {
    if (value > 150) return 'text-destructive'
    if (value > 100) return 'text-yellow-500'
    return 'text-green-500'
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-primary p-2">
                <Activity className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-semibold">IoT Monitoring</h1>
                <p className="text-sm text-muted-foreground">Load Cell Strain Monitoring System</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Calendar className="mr-2 h-4 w-4" />
                Last 24 Hours
              </Button>
              <Button variant="ghost" size="icon">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* KPI Cards */}
        <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {/* Live Strain */}
          <Card className="border-border bg-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Live Strain</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end gap-2">
                <span className={`text-3xl font-bold ${getStatusColor(liveStrain)}`}>
                  {isLoading ? '—' : liveStrain.toFixed(1)}
                </span>
                <span className="text-sm text-muted-foreground mb-1">μ-strain</span>
              </div>
              <div className="mt-2 flex items-center gap-1 text-xs text-muted-foreground">
                <TrendingUp className="h-3 w-3" />
                <span>Real-time measurement</span>
              </div>
            </CardContent>
          </Card>

          {/* Max Strain */}
          <Card className="border-border bg-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Peak Strain</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end gap-2">
                <span className="text-3xl font-bold text-foreground">
                  {isLoading ? '—' : maxStrain.toFixed(1)}
                </span>
                <span className="text-sm text-muted-foreground mb-1">μ-strain</span>
              </div>
              <div className="mt-2 text-xs text-muted-foreground">24-hour maximum</div>
            </CardContent>
          </Card>

          {/* Average Strain */}
          <Card className="border-border bg-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Average Strain</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end gap-2">
                <span className="text-3xl font-bold text-foreground">
                  {isLoading ? '—' : avgStrain.toFixed(1)}
                </span>
                <span className="text-sm text-muted-foreground mb-1">μ-strain</span>
              </div>
              <div className="mt-2 text-xs text-muted-foreground">24-hour average</div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          {/* Strain Trend */}
          <Card className="border-border bg-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Strain Trend</CardTitle>
                  <CardDescription>24-hour historical data</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                    <XAxis dataKey="time" stroke="var(--color-muted-foreground)" />
                    <YAxis stroke="var(--color-muted-foreground)" />
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: 'var(--color-card)',
                        border: '1px solid var(--color-border)',
                        borderRadius: '8px'
                      }}
                      formatter={(value: any) => [value.toFixed(2) + ' μ-strain', 'Strain']}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="strain" 
                      stroke="var(--color-chart-1)" 
                      strokeWidth={2}
                      dot={false}
                      isAnimationActive={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Strain Distribution */}
          <Card className="border-border bg-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Strain Distribution</CardTitle>
                  <CardDescription>Cumulative 24-hour load</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData}>
                    <defs>
                      <linearGradient id="colorStrain" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="var(--color-chart-2)" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="var(--color-chart-2)" stopOpacity={0.1}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                    <XAxis dataKey="time" stroke="var(--color-muted-foreground)" />
                    <YAxis stroke="var(--color-muted-foreground)" />
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: 'var(--color-card)',
                        border: '1px solid var(--color-border)',
                        borderRadius: '8px'
                      }}
                      formatter={(value: any) => [value.toFixed(2) + ' μ-strain', 'Cumulative']}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="strain" 
                      stroke="var(--color-chart-2)"
                      fillOpacity={1} 
                      fill="url(#colorStrain)"
                      isAnimationActive={false}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sensor Status */}
        <Card className="mt-6 border-border bg-card">
          <CardHeader>
            <CardTitle>Sensor Status</CardTitle>
            <CardDescription>Load cell and system health</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { label: 'Load Cell', status: 'Active', color: 'bg-green-500/20' },
                { label: 'Signal Quality', status: '95%', color: 'bg-green-500/20' },
                { label: 'Data Sampling', status: '1 Hz', color: 'bg-blue-500/20' },
                { label: 'System Load', status: 'Normal', color: 'bg-green-500/20' },
              ].map((item) => (
                <div key={item.label} className={`rounded-lg border border-border ${item.color} p-4`}>
                  <div className="flex items-center gap-2">
                    <div className={`h-2 w-2 rounded-full ${item.color.replace('bg-', 'bg-').replace('/20', '')}`} />
                    <p className="text-sm font-medium text-muted-foreground">{item.label}</p>
                  </div>
                  <p className="mt-2 text-lg font-semibold">{item.status}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
