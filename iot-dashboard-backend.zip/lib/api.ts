// lib/api.ts
import { fetchSensorData } from '@/lib/supabase'
const API_BASE =
  process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000/api";

export async function fetchSensorData() {
  const res = await fetch(`${API_BASE}/sensor/data`, {
    method: "GET",
    cache: "no-store",
  });

  if (!res.ok) throw new Error("Failed to fetch sensor data");

  const data = await res.json();
  return data;
}
